var loadProfileImages = function(callback){
	$.ajax({
	    url: "/user-settings/general/get-profile-image-path",
	    type: "GET",
	    cache: false,
	    	    
	    success: function(response) { 
	    	if(Boolean(response.success) == true){
	    		$(".personProfileNavigationImageBig,.personProfileNavigationImage").css("background-image","url('"+response.path+"')");
	    		if(callback){callback(response);} 
			}else{
				$(".personProfileNavigationImageBig,.personProfileNavigationImage").css("background-image","url('/images/system/user-default.png')");
				$(".personProfileNavigationImageBig,.personProfileNavigationImage").addClass("default-profile-image");
				if(callback){callback(response);} 
			}
		},
	    error: function(response) {
	    	if(callback){callback(response);} 
	    },
	    complete: function(result) { 
	    	 
	    }
	}); 
}