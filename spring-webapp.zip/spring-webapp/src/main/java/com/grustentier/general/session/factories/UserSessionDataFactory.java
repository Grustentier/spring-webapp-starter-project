package com.grustentier.general.session.factories;

import com.grustentier.general.dao.services.UserAccessService;
import com.grustentier.general.session.ActiveUserSessionDataStore;
import com.grustentier.general.session.LoggedUser;
import com.grustentier.general.session.UserSessionData;

public class UserSessionDataFactory {

	public static UserSessionData createUserSessionData(LoggedUser loggedUser,
			ActiveUserSessionDataStore activeUserStore, UserAccessService userAccessService) {
		return new UserSessionData(loggedUser, activeUserStore,userAccessService);
	}

	public static UserSessionData createCopy(UserSessionData userSessionData) {
		try {
			return (UserSessionData) userSessionData.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return null;
	}

}
