package com.grustentier.general.session;

import com.grustentier.general.dao.User;

public class LoggedUser {

	private Long userId;
	private String username;
	private String firstname;
	private String lastname;

	public LoggedUser(String username) {
		this.username = username;
	}

	public LoggedUser(User user) {
		this.userId = user.getId();
		this.username = user.getUsername();
		this.firstname = user.getFirstname();
		this.lastname = user.getLastname();
	}

	public Long getUserId() {
		return this.userId;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public String getUsername() {
		return this.username;
	}

}