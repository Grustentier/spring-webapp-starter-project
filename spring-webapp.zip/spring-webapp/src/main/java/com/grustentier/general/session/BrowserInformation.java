package com.grustentier.general.session;

public class BrowserInformation {
	private String userAgendHeader;

	public BrowserInformation() {

	}

	public String getUserAgendHeader() {
		return userAgendHeader;
	}

	public void setUserAgendHeader(String userAgendHeader) {
		this.userAgendHeader = userAgendHeader;
	}
}
