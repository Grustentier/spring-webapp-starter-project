package com.grustentier.general.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grustentier.general.dao.ProfileImage;

@Repository
public interface ProfileImageRepository extends JpaRepository<ProfileImage, Long> {
	
	@Query(value = "select * from profile_image where user_id = :userId", nativeQuery = true)
	public ProfileImage getByUserId(@Param("userId") Long userId);
}
