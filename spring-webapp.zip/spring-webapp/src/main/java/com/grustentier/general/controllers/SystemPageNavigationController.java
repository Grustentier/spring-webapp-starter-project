package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SystemPageNavigationController extends ControllerFacade {

	@GetMapping("/system")
	public String navToSystemHome(HttpServletRequest request) {
		updateNavigationHistory(request);
		return "/system/index";
	}

}
