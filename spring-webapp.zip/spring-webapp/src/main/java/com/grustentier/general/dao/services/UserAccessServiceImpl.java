package com.grustentier.general.dao.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.authentication.configurations.SecurityContextFacade;
import com.grustentier.general.dao.UserAccess;
import com.grustentier.general.dao.repositories.UserAccessRepository;

@Service
public class UserAccessServiceImpl extends SecurityContextFacade implements UserAccessService {

	@Autowired
	private UserAccessRepository userAccessRepository;

	@Override
	public List<UserAccess> getUserAccesses() {
		Long userId = getUserId();

		if (userId == null) {
			return Collections.emptyList();
		}

		return (List<UserAccess>) userAccessRepository.getUserAccessesByUserId(userId);
	}

	@Override
	public UserAccess getLastUserAccess(Long userId) { 
		if (userId == null) {
			return null;
		}

		return userAccessRepository.getLastUserAccess(userId);
	}

	@Override
	public void saveUserAccess(UserAccess userAccess) {
		if (userAccess == null) {
			return;
		}
		userAccessRepository.save(userAccess);
	}

	@Override
	public boolean lastLogoutWasManual() {
		Long userId = getUserId();

		if (userId == null) {
			return false;
		}

		UserAccess ua = userAccessRepository.getLastUserAccess(userId);

		if (ua == null) {
			return false;
		}

		return ua.wasManualLogout();
	}

}
