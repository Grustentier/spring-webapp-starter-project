package com.grustentier.general.dao.services;

import java.util.List;

import com.grustentier.general.dao.UserAccess;

public interface UserAccessService {

	List<UserAccess> getUserAccesses();

	UserAccess getLastUserAccess(Long userId);

	void saveUserAccess(UserAccess userAccess);

	boolean lastLogoutWasManual();
}
