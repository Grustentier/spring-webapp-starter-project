package com.grustentier.general.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grustentier.general.dao.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
}

/*
 * @Repository public interface UserRepository extends CrudRepository<User,
 * Long> { }
 */
