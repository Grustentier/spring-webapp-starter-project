package com.grustentier.general.authentication.configurations;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.grustentier.general.authentication.AuthenticationUserDetails;
import com.grustentier.general.dao.User;

public class SecurityContextFacade {

	public AuthenticationUserDetails getAuthenticationUserDetails() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication != null) {
			return (AuthenticationUserDetails) authentication.getPrincipal();
		}

		return null;
	}

	public Long getUserId() {
		AuthenticationUserDetails aud = getAuthenticationUserDetails();
		if (aud == null || aud.getUser() == null) {
			return null;
		}

		return aud.getUser().getId();
	}

	public User getUserFromContext() {
		AuthenticationUserDetails aud = getAuthenticationUserDetails();
		if (aud == null) {
			return null;
		}

		return aud.getUser();
	}

}
