package com.grustentier.general.authentication.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.grustentier.general.authentication.AuthenticationSuccessHandlerImpl;
import com.grustentier.general.authentication.services.AuthenticationUserDetailsService;
import com.grustentier.general.logout.LogoutSuccessHandlerImpl;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Bean
	public UserDetailsService userDetailsService() {
		return new AuthenticationUserDetailsService();
	}

	/*
	 * Use this password encoder for plain passwords
	@Bean
	public DelegatingPasswordEncoder passwordEncoder() {
		return (DelegatingPasswordEncoder) PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}*/
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService());
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

	@Bean
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new AuthenticationSuccessHandlerImpl();
	}
	
	@Bean
	public LogoutSuccessHandler logoutSuccessHandler() {
		return new LogoutSuccessHandlerImpl();
	}

	/**
	 * https://ducmanhphan.github.io/2019-02-22-Logout-in-Spring-Boot/
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).invalidSessionUrl("/login");
		http.authorizeRequests().
		antMatchers("/").permitAll().
		antMatchers("/images/**").permitAll().
		antMatchers("/api/**").permitAll().
		antMatchers("/system/**").hasAnyAuthority("ADMIN","USER").
		antMatchers("/administration/**").hasAuthority("ADMIN").
		anyRequest().authenticated().
		and().
		formLogin().		
		loginPage("/login").
		//defaultSuccessUrl("/access-granted").
		failureUrl("/login?error=accessDenied").
		successHandler(authenticationSuccessHandler()).
		permitAll().
		and().
		logout().
		logoutSuccessHandler(logoutSuccessHandler()).
		logoutRequestMatcher(new AntPathRequestMatcher("/logout")).
		invalidateHttpSession(true).
		deleteCookies("JSESSIONID").
        permitAll().
        and().
		exceptionHandling().
		accessDeniedPage("/403");		
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

}