package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.grustentier.general.login.LoginResult;

@Controller
public class LoginPageNavigationController extends ControllerFacade {

	@GetMapping("/login")
	public String navToLoginPage(@RequestParam(name = "error", required = false) String error, Model model,
			HttpServletRequest request) {

		// If already logged in, navigate to alreadyLoggedIn.html infor page.
		if (error == null) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			System.out.println(auth);
			if (!(auth instanceof AnonymousAuthenticationToken)) {
				updateNavigationHistory(request);
				return "/info/alreadyLoggedIn";
			}
		}

		// If error != null, reason by wrong username or password, notify access denied
		// in /login/index.html.
		if (error != null) {
			LoginResult loginResult = new LoginResult();
			loginResult.setMessage("Access Denied");
			loginResult.setAccessPermitted(false);
			model.addAttribute("loginResult", loginResult);
		}
		return "/login/index";
	}

}
