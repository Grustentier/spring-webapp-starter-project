package com.grustentier.general.configurations;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.grustentier.general.utils.PathUtils;

@Configuration
public class WebConfiguration extends WebMvcConfigurationSupport {

	@Autowired
	PathUtils pathUtils;	 

	@Override
	protected void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/images/**").addResourceLocations("classpath:/static/images/");
		registry.addResourceHandler("/css/**").addResourceLocations("classpath:/static/css/");
		registry.addResourceHandler("/javascript/**").addResourceLocations("classpath:/static/javascript/");		 
		registry.addResourceHandler(pathUtils.getInternalDataStorePath().toString() + "/**").addResourceLocations("file:" + pathUtils.getExternalDataStorePath().toString()+File.separator);
	}
}
