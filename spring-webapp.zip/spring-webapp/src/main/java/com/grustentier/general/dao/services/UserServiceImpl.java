package com.grustentier.general.dao.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.authentication.configurations.SecurityContextFacade;
import com.grustentier.general.dao.User;
import com.grustentier.general.dao.repositories.UserRepository;

@Service
public class UserServiceImpl extends SecurityContextFacade implements UserService {

	@Autowired
	private UserRepository userRepository;
	 

	@Override
	public User getUser() {
		Long userId = getUserId();
		if (userId == null) {
			return null;
		}
		return userRepository.getUserById(userId);
	}

	@Override
	public boolean userExists(String username) {
		return userRepository.getUserByUsername(username) != null;
	}

	@Override
	public void saveUser(User user) {
		userRepository.save(user);
	}

}
