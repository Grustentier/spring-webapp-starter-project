package com.grustentier.general.dao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.dao.User;
import com.grustentier.general.dao.repositories.UserRepository;

@Service
public class UserServiceImpl {

	@Autowired
	private UserRepository userRepository;

	public List<User> getUsers() {
		return (List<User>) userRepository.findAll();
	}

	public User getUser(String username) {
		return userRepository.getUserByUsername(username);
	}

	public User getUser(Long id) {
		return userRepository.getById(id);
	}

}
