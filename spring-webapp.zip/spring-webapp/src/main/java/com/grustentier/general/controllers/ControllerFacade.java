package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import com.grustentier.general.session.SessionFacade;
import com.grustentier.general.session.UserSessionData;

public class ControllerFacade extends SessionFacade {

	protected void updateNavigationHistory(HttpServletRequest request) {
		UserSessionData userSessionData = getUserSessionDataFromSession(request.getSession());
		if (userSessionData != null) {
			userSessionData.getNavigationHistory().add(request.getRequestURI());
		}
	}

}
