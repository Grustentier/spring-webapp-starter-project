package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import com.grustentier.general.session.SessionFacade;
import com.grustentier.general.session.UserSessionData;

public class ControllerFacade extends SessionFacade {

	protected void updateNavigationHistory(HttpServletRequest request) {
		UserSessionData userSessionData = getUserSessionDataFromSession(request.getSession());
		if (userSessionData == null) {
			return;
		}
		StringBuilder requestURL = new StringBuilder(request.getRequestURI());
		String queryString = request.getQueryString();
		if (queryString != null) {
			requestURL.append('?').append(queryString);
		}
		userSessionData.getNavigationHistory().add(requestURL.toString());

	}

}
