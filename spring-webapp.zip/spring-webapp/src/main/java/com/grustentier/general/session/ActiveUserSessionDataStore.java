package com.grustentier.general.session;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ActiveUserSessionDataStore {

	public List<UserSessionData> activeUserSessionData;

	public ActiveUserSessionDataStore() {
		activeUserSessionData = new ArrayList<UserSessionData>();
	}

	public List<UserSessionData> getActiveUserSessionData() {
		return activeUserSessionData;
	}

	public UserSessionData findExistingUserSessionData(String username) {
		if (username == null) {
			return null;
		}

		Optional<UserSessionData> optional = activeUserSessionData.parallelStream()
				.filter(element -> element.getLoggedUser().getUsername().equals(username)).findFirst();
		if (optional == null || optional.isEmpty()) {
			return null;
		}

		return (UserSessionData) optional.get();
	}

}
