package com.grustentier.general.utils;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.grustentier.general.authentication.configurations.SecurityContextFacade;

@Component
public class PathUtils extends SecurityContextFacade {

	@Value("${internal.data.storage.path}")
	private String internalDataStoragePath;

	@Value("${external.data.storage.path}")
	private String externalDataStoragePath;

	public Path getInternalDataStorePath() {
		return Paths.get(internalDataStoragePath);
	}

	public Path getExternalDataStorePath() {
		return Paths.get(externalDataStoragePath);
	}

	public Path getInternalUserDataStorePath() {
		return Paths.get(getInternalDataStorePath().toString(), getUserId().toString());
	}

	public Path getExternalUserDataStorePath() {
		return Paths.get(externalDataStoragePath, getUserId().toString());
	}

	public Path getInternalProfileImagePath() {
		return Paths.get(getInternalUserDataStorePath().toString(), "profile-image");
	}

	public Path getExternalProfileImagePath() {
		return Paths.get(getExternalUserDataStorePath().toString(), "profile-image");
	}
}
