package com.grustentier.general.file.services;

import java.nio.file.Path;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

public interface FileStorageService {

	public void createDirectory(Path targetDirectoryToCreate);

	public void save(MultipartFile file, Path targetFilePath);

	public void save(List<CommonsMultipartFile> uploadedFiles, String targetStorePath);

	public void deleteDirectory(Path directoryToDelete);
	
	public void deleteFile(Path fileToDelete);

	public void cleanDirectory(Path directoryToClean);
}
