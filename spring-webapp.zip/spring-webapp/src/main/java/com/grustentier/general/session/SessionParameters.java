package com.grustentier.general.session;

public enum SessionParameters {

	USER_SESSION_DATA;

}
