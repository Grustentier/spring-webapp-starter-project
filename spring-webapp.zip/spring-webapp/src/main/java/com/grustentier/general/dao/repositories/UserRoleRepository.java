package com.grustentier.general.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grustentier.general.dao.UserRole;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, Long> {
}

/*
 * @Repository public interface UserRepository extends CrudRepository<User,
 * Long> { }
 */
