package com.grustentier.general.session.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.grustentier.general.session.ActiveUserSessionDataStore;

@Configuration
public class ActiveUserSessionDataStoreConfig {

	@Bean
	public ActiveUserSessionDataStore activeUserSessionDataStore(){
	    return new ActiveUserSessionDataStore();
	}
}
