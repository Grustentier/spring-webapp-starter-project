package com.grustentier.general.dao.services;

import com.grustentier.general.dao.ProfileImage;

public interface ProfileImageService {

	public ProfileImage getProfileImage();

	public void save(ProfileImage profileImage);

	public void delete(ProfileImage profileImage);
}
