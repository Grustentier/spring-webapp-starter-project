package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ErrorPageNavigationController extends ControllerFacade implements ErrorController {

	@GetMapping("/accessDenied")
	public String navToAccessDeniedPage(HttpServletRequest request) {
		updateNavigationHistory(request);
		return "/error/accessDenied";
	}

	@GetMapping("/403")
	public String navTo403Page(HttpServletRequest request) {
		updateNavigationHistory(request);
		return "/error/403";
	}

}
