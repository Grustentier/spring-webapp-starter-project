package com.grustentier.general.authentication;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.grustentier.general.session.ActiveUserSessionDataStore;
import com.grustentier.general.session.LoggedUser;
import com.grustentier.general.session.SessionParameters;
import com.grustentier.general.session.UserSessionData;
import com.grustentier.general.session.factories.UserSessionDataFactory;

public class AuthenticationSuccessHandlerImpl implements AuthenticationSuccessHandler {

	@Autowired
	ActiveUserSessionDataStore activeUserSessionDataStore;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		HttpSession session = request.getSession(false);
		if (session != null) {
			AuthenticationUserDetails aud = (AuthenticationUserDetails) authentication.getPrincipal();

			/*
			 * UserSessionData userSessionData =
			 * activeUserSessionDataStore.findExistingUserSessionData(aud.getUsername());
			 * 
			 * if (userSessionData == null) { userSessionData =
			 * UserSessionDataFactory.createUserSessionData(new LoggedUser(aud.getUser()),
			 * activeUserSessionDataStore);
			 * 
			 * } else { userSessionData =
			 * UserSessionDataFactory.createCopy(userSessionData);
			 * 
			 * }
			 */

			UserSessionData userSessionData = UserSessionDataFactory
					.createUserSessionData(new LoggedUser(aud.getUser()), activeUserSessionDataStore);

			final String browserDetails = request.getHeader("User-Agent");
			userSessionData.getBrowserInformation().setUserAgendHeader(browserDetails.toLowerCase());
			userSessionData.getUserSessionTime().setSessionCreationTime(request.getSession().getCreationTime());
			userSessionData.getUserSessionTime().setLoginTime(System.currentTimeMillis());

			session.setAttribute(SessionParameters.USER_SESSION_DATA.toString(), userSessionData);

			System.out.println(
					"AuthenticationSuccessHandler: user(" + authentication.getName() + ") logged successfully in...");
		}

		response.sendRedirect("/system");
	}

}