package com.grustentier.general.dao.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.dao.User;
import com.grustentier.general.dao.UserRole;
import com.grustentier.general.dao.repositories.UserRoleRepository;

@Service
public class UserRoleServiceImpl {

	@Autowired
	private UserRoleRepository userRoleRepository;

	public List<UserRole> getUserRoles() {
		return (List<UserRole>) userRoleRepository.findAll();
	}

	/**
	 * CURRENTLY NOT IN USE
	 * @param user
	 * @return
	 */
	public List<UserRole> getUserRoles(User user) { 
		return getUserRoles().stream().parallel().filter(element -> element.getUserId() == user.getId()).collect(Collectors.toList());
	}

}
