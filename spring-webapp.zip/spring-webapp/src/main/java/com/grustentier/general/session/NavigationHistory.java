package com.grustentier.general.session;

import java.util.ArrayList;
import java.util.List;

public class NavigationHistory {
	private List<String> history;

	public NavigationHistory() {
		this.history = new ArrayList<String>();
	}

	public List<String> getHistory() {
		return history;
	}

	public void add(String mapping) {
		int lastIndex = this.history.lastIndexOf(mapping);
		if (lastIndex <= this.history.size() - 1) {
			this.history.add(mapping);
		}
	}
}
