package com.grustentier.general.dao.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.authentication.configurations.SecurityContextFacade;
import com.grustentier.general.dao.ProfileImage;
import com.grustentier.general.dao.repositories.ProfileImageRepository;

@Service
public class ProfileImageServiceImpl extends SecurityContextFacade implements ProfileImageService {

	@Autowired
	private ProfileImageRepository profileImageRepository;

	@Override
	public ProfileImage getProfileImage() {
		Long userId = getUserId();

		if (userId == null) {
			return null;
		}

		return profileImageRepository.getByUserId(userId);
	}

	@Override
	public void save(ProfileImage profileImage) {
		profileImageRepository.save(profileImage);
	}

	@Override
	public void delete(ProfileImage profileImage) {
		profileImageRepository.delete(profileImage);
	}
}
