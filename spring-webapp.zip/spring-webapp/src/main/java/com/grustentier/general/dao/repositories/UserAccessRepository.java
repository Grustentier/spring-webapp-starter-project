package com.grustentier.general.dao.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grustentier.general.dao.UserAccess;

@Repository
public interface UserAccessRepository extends JpaRepository<UserAccess, Long> {

	@Query(value = "select * from user_access where user_id = :userId order by id DESC", nativeQuery = true)
	public List<UserAccess> getUserAccessesByUserId(@Param("userId") Long userId);
	
	@Query(value = "select * from user_access where user_id = :userId order by id DESC LIMIT 1", nativeQuery = true)
	public UserAccess getLastUserAccess(@Param("userId") Long userId);
	 
}
