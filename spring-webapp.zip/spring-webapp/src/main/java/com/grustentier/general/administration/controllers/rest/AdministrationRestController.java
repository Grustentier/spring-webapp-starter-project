package com.grustentier.general.administration.controllers.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grustentier.general.session.ActiveUserSessionDataStore;
import com.grustentier.general.session.UserSessionData;

@RestController
public class AdministrationRestController {

	@Autowired
	ActiveUserSessionDataStore activeUserSessionDataStore;

	@GetMapping(value = "/administration/getActiveUsers")
	public List<UserSessionData> getLoggedUsers(Model model, HttpServletRequest request) {

		return activeUserSessionDataStore.getActiveUserSessionData();

	}
}
