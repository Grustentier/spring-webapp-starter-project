package com.grustentier.general.administration.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.grustentier.general.session.SessionParameters;
import com.grustentier.general.session.UserSessionData;

@Controller
public class AdministrationPageNavigationController {

	@GetMapping(value = "/administration")
	public String navToAdministrationHome(HttpServletRequest request) {
		UserSessionData userSessionData = (UserSessionData) request.getSession().getAttribute(SessionParameters.USER_SESSION_DATA.name());
		if (userSessionData != null) {
			userSessionData.getNavigationHistory().add("/administration");
		}
		return "/administration/index";
	}

	@GetMapping(value = "/administration/activeUsers")
	public String navToActiveUsersPage(HttpServletRequest request) {
		UserSessionData userSessionData = (UserSessionData) request.getSession().getAttribute(SessionParameters.USER_SESSION_DATA.name());
		if (userSessionData != null) {
			userSessionData.getNavigationHistory().add("/administration/activeUsers");
		}
		return "/administration/activeUsers";
	}

}
