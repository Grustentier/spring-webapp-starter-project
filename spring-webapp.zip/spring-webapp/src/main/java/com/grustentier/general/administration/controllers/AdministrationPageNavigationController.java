package com.grustentier.general.administration.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.grustentier.general.controllers.ControllerFacade;

@Controller
@RequestMapping("/administration")
public class AdministrationPageNavigationController extends ControllerFacade {

	@GetMapping(value = "/")
	public String navToAdministrationHome(@RequestParam(name = "parent", required = false) String parent,
			@RequestParam(name = "tab", required = false) String tab, HttpServletRequest request, Model model) {
		updateNavigationHistory(request);

		model.addAttribute("parent", parent);
		model.addAttribute("tab", tab);
		return "/administration/index";
	}

}
