package com.grustentier.general.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProfileImage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "internal_file_path")
	private String internalFilePath;

	@Column(name = "external_file_path")
	private String externalFilePath;

	@Column(name = "filename")
	private String filename;

	@Column(name = "user_id")
	private Long userId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInternalFilePath() {
		return internalFilePath;
	}

	public void setInternalFilePath(String internalFilePath) {
		this.internalFilePath = internalFilePath;
	}

	public String getExternalFilePath() {
		return externalFilePath;
	}

	public void setExternalFilePath(String externalFilePath) {
		this.externalFilePath = externalFilePath;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
