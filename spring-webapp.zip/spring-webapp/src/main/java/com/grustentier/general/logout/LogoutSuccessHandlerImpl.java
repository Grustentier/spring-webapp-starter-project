package com.grustentier.general.logout;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import com.grustentier.general.dao.UserAccess;
import com.grustentier.general.dao.services.UserAccessService;
import com.grustentier.general.session.SessionParameters;
import com.grustentier.general.session.UserSessionData;

public class LogoutSuccessHandlerImpl implements LogoutSuccessHandler {

	@Autowired
	UserAccessService userAccessService;

	@Override
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {

		// Register logout in database table user_access
		HttpSession session = request.getSession();
		if (session != null) {
			UserSessionData usd = (UserSessionData) session.getAttribute(SessionParameters.USER_SESSION_DATA.name());
			UserAccess ua = userAccessService.getLastUserAccess(usd.getLoggedUser().getId());
			if (ua != null) {
				ua.setManualLogout(true);
				ua.setLogoutTime(System.currentTimeMillis());
				userAccessService.saveUserAccess(ua);
			}
		}

		SecurityContextLogoutHandler sclh = new SecurityContextLogoutHandler();
		sclh.setClearAuthentication(true);
		sclh.setInvalidateHttpSession(true);
		sclh.logout(request, response, authentication);

		response.sendRedirect("/");
	}

}
