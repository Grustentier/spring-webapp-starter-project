package com.grustentier.general.session;

import java.util.List;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.springframework.stereotype.Component;

import com.grustentier.general.dao.UserAccess;
import com.grustentier.general.dao.services.UserAccessService;

@Component
public class UserSessionData implements HttpSessionBindingListener, Cloneable {

	private LoggedUser loggedUser;
	private UserSessionTime userSessionTime;
	private BrowserInformation browserInformation;
	private NavigationHistory navigationHistory;

	private ActiveUserSessionDataStore activeUserSessionDataStore;
	private UserAccessService userAccessService;

	public UserSessionData(LoggedUser loggedUser, ActiveUserSessionDataStore activeUserStore,
			UserAccessService userAccessService) {
		this.loggedUser = loggedUser;
		this.activeUserSessionDataStore = activeUserStore;
		this.userAccessService = userAccessService;
		this.browserInformation = new BrowserInformation();
		this.navigationHistory = new NavigationHistory();
		this.userSessionTime = new UserSessionTime();
	}

	public BrowserInformation getBrowserInformation() {
		return this.browserInformation;
	}

	public UserSessionTime getUserSessionTime() {
		return this.userSessionTime;
	}

	public NavigationHistory getNavigationHistory() {
		return this.navigationHistory;
	}

	public LoggedUser getLoggedUser() {
		return this.loggedUser;
	}

	@Override
	public void valueBound(HttpSessionBindingEvent event) {
		List<UserSessionData> userSessionDataFromStore = this.activeUserSessionDataStore.getActiveUserSessionData();
		UserSessionData currentUserSessionData = (UserSessionData) event.getValue();

		if (!userSessionDataFromStore.contains(currentUserSessionData)) {
			userSessionDataFromStore.add(currentUserSessionData);
		}

	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		List<UserSessionData> userSessionDataFromStore = this.activeUserSessionDataStore.getActiveUserSessionData();
		UserSessionData currentUserSessionData = (UserSessionData) event.getValue();

		// Register logout in database table user_access
		UserAccess ua = userAccessService.getLastUserAccess(currentUserSessionData.getLoggedUser().getId());
		if (ua != null) {
			ua.setLogoutTime(System.currentTimeMillis());
			userAccessService.saveUserAccess(ua);
		}

		if (userSessionDataFromStore.contains(currentUserSessionData)) {
			userSessionDataFromStore.remove(currentUserSessionData);
		}
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
