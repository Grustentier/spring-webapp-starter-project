package com.grustentier.general.session;

import java.util.List;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.springframework.stereotype.Component;

@Component
public class UserSessionData implements HttpSessionBindingListener, Cloneable {

	private LoggedUser loggedUser;
	private UserSessionTime userSessionTime;
	private BrowserInformation browserInformation;
	private NavigationHistory navigationHistory;

	private ActiveUserSessionDataStore activeUserSessionDataStore;

	public UserSessionData(LoggedUser loggedUser, ActiveUserSessionDataStore activeUserStore) {
		this.loggedUser = loggedUser;
		this.activeUserSessionDataStore = activeUserStore;
		this.browserInformation = new BrowserInformation();
		this.navigationHistory = new NavigationHistory();
		this.userSessionTime = new UserSessionTime();
	}

	public BrowserInformation getBrowserInformation() {
		return this.browserInformation;
	}

	public UserSessionTime getUserSessionTime() {
		return this.userSessionTime;
	}

	public NavigationHistory getNavigationHistory() {
		return this.navigationHistory;
	}

	public LoggedUser getLoggedUser() {
		return this.loggedUser;
	}

	@Override
	public void valueBound(HttpSessionBindingEvent event) {
		List<UserSessionData> userSessionDataFromStore = this.activeUserSessionDataStore.getActiveUserSessionData();
		UserSessionData currentUserSessionData = (UserSessionData) event.getValue();

		if (!userSessionDataFromStore.contains(currentUserSessionData)) {
			userSessionDataFromStore.add(currentUserSessionData);
		}

	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		List<UserSessionData> userSessionDataFromStore = this.activeUserSessionDataStore.getActiveUserSessionData();
		UserSessionData currentUserSessionData = (UserSessionData) event.getValue();

		if (userSessionDataFromStore.contains(currentUserSessionData)) {
			userSessionDataFromStore.remove(currentUserSessionData);
		}
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
