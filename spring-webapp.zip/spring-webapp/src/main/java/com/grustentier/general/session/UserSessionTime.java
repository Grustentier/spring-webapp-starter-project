package com.grustentier.general.session;

public class UserSessionTime {

	private Long loginTime;
	private Long sessionCreationTime;

	private Long logoutTime;

	public UserSessionTime() {
	}

	public Long getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Long loginTime) {
		this.loginTime = loginTime;
	}

	public Long getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(Long logoutTime) {
		this.logoutTime = logoutTime;
	}

	public Long getSessionCreationTime() {
		return sessionCreationTime;
	}

	public void setSessionCreationTime(Long sessionCreationTime) {
		this.sessionCreationTime = sessionCreationTime;
	}
}
