package com.grustentier.general.dao.services;

import com.grustentier.general.dao.User;

public interface UserService {

	User getUser();

	boolean userExists(String username);

	void saveUser(User user);

}
