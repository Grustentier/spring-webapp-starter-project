package com.grustentier.general.dao.services;

import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

}
