package com.grustentier.general.dao.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grustentier.general.dao.Role;
import com.grustentier.general.dao.User;
import com.grustentier.general.dao.UserRole;
import com.grustentier.general.dao.repositories.RoleRepository;

@Service
public class RoleServiceImpl {

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	UserRoleServiceImpl userRoleService;

	public List<Role> getRoles() {
		return (List<Role>) roleRepository.findAll();
	}

	/**
	 * CURRENTLY NOT IN USE
	 * @param user
	 * @return
	 */
	public List<Role> getUserRoles(User user) {
		List<UserRole> userRoles = userRoleService.getUserRoles(user);

		List<Role> roles = new ArrayList<Role>();
		for (UserRole userRole : userRoles) {
			roles.addAll(getRoles().stream().parallel().filter(element -> element.getId() == userRole.getRoleId())
					.collect(Collectors.toList()));
		}

		return roles;

	}

}
