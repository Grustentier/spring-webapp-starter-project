package com.grustentier.general.file.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Service
public class FilesStorageServiceImpl implements FileStorageService {

	@Override
	public void createDirectory(Path targetDirectoryToCreate) {
		try {
			if (!Files.exists(targetDirectoryToCreate)) {
				Files.createDirectories(targetDirectoryToCreate);
			}
		} catch (IOException e) {
			throw new RuntimeException("Could not initialize folder for upload!");
		}
	}

	@Override
	public void save(MultipartFile file, Path targetFilePath) {
		try {
			// file.transferTo(targetFilePath);
			Files.copy(file.getInputStream(), targetFilePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
		}
	}

	@Override
	public void deleteDirectory(Path directoryToDelete) {
		if (!Files.exists(directoryToDelete)) {
			return;
		}

		FileSystemUtils.deleteRecursively(directoryToDelete.toFile());
	}

	@Override
	public void save(List<CommonsMultipartFile> uploadedFiles, String targetStorePath) {
		try {
			Path docRootPath = Path.of(targetStorePath);
			if (!Files.exists(docRootPath)) {
				Files.createDirectory(docRootPath);
			}
			for (CommonsMultipartFile multipartFile : uploadedFiles) {
				copy(multipartFile, targetStorePath);
			}
		} catch (IOException e) {
			throw new RuntimeException("Could not store the files. Error: " + e.getMessage());
		}
	}

	private void copy(MultipartFile multipartFile, String targetStorePath) throws IOException {
		String fileName = multipartFile.getOriginalFilename();
		String normalizedFileName = FilenameUtils.normalize(fileName);
		multipartFile.transferTo(Path.of(targetStorePath, normalizedFileName));
	}

	@Override
	public void cleanDirectory(Path directoryToClean) {
		if (!Files.exists(directoryToClean)) {
			return;
		}

		try {
			FileUtils.cleanDirectory(directoryToClean.toFile());
		} catch (IOException e) {
			throw new RuntimeException("Could not clean the directory. Error: " + e.getMessage());
		}
	}

	@Override
	public void deleteFile(Path fileToDelete) {
		if (!Files.exists(fileToDelete)) {
			return;
		}

		try {
			Files.delete(fileToDelete);
		} catch (IOException e) {
			throw new RuntimeException("Could not delete the directory. Error: " + e.getMessage());
		}
	}
}
