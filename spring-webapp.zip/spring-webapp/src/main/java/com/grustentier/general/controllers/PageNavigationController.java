package com.grustentier.general.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageNavigationController extends ControllerFacade {

	@GetMapping("/")
	public String navToLoginPage(Model model, HttpServletRequest request) {
		updateNavigationHistory(request);
		return "/index";
	}
}
