package com.grustentier.general.authentication;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.grustentier.general.dao.User;
import com.grustentier.general.dao.UserRole;

public class AuthenticationUserDetails implements UserDetails {

	private static final long serialVersionUID = 1L;

	private User user;

	public AuthenticationUserDetails(User user) {
		this.user = user;
	}

	public User getUser() {
		return this.user;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		for (UserRole ur : this.user.getUserRoles()) {
			authorities.add(new SimpleGrantedAuthority(ur.getRole().getName().toUpperCase()));
		}

		return authorities;
	}

	@Override
	public String getPassword() {
		// return "{noop}" + this.password; // for plain password
		return this.user.getPassword();
	}

	@Override
	public String getUsername() {
		return this.user.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}
