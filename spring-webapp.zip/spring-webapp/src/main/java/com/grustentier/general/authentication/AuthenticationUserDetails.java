package com.grustentier.general.authentication;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.grustentier.general.dao.User;
import com.grustentier.general.dao.UserRole;

public class AuthenticationUserDetails implements UserDetails {

	private static final long serialVersionUID = 1L;

	private User user;
	private Long userId;
	private String username;
	private String password;
	private Collection<UserRole> userRoles;

	public AuthenticationUserDetails(Long userId, String username, String password, Collection<UserRole> userRoles) {
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.userRoles = userRoles;
	}

	public AuthenticationUserDetails(User user) {
		this.user = user;
		this.userId = user.getId();
		this.username = user.getUsername();
		this.password = user.getPassword();
		this.userRoles = user.getUserRoles();
	}

	public User getUser() {
		return this.user;
	}

	public Long getUserId() {
		return this.userId;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		for (UserRole ur : this.userRoles) {
			authorities.add(new SimpleGrantedAuthority(ur.getRole().getName().toUpperCase()));
		}

		return authorities;
	}

	@Override
	public String getPassword() {
		// return "{noop}" + this.password; // for plain password
		return this.password;
	}

	@Override
	public String getUsername() {
		return this.username;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
