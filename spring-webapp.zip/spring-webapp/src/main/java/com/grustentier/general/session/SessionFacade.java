package com.grustentier.general.session;

import javax.servlet.http.HttpSession;

public class SessionFacade {

	protected UserSessionData getUserSessionDataFromSession(HttpSession session) {
		return (UserSessionData) session.getAttribute(SessionParameters.USER_SESSION_DATA.name());
	}

}
