package com.grustentier.general.session;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionException;

import com.grustentier.general.authentication.configurations.SecurityContextFacade;

public class SessionFacade extends SecurityContextFacade {

	private final Log logger = LogFactory.getLog(SessionFacade.class);

	protected UserSessionData getUserSessionDataFromSession(HttpSession session) {
		if (session == null) {
			logger.error("SessionFacade : getUserSessionDataFromSession :HttpSession ist null!");
			throw new SessionException("HttpSession ist null!");
		}

		UserSessionData userSessionData = (UserSessionData) session
				.getAttribute(SessionParameters.USER_SESSION_DATA.name());

		if (userSessionData == null) {
			return null;
		}

		return userSessionData;
	}

}
