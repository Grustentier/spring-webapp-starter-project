package com.grustentier.general.dao.services;

public interface RoleService {

}
