package com.grustentier.general.login;

public class LoginResult {

	String message;

	Boolean accessPermitted = false;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Boolean getAccessPermitted() {
		return accessPermitted;
	}

	public void setAccessPermitted(Boolean accessPermitted) {
		this.accessPermitted = accessPermitted;
	}

}
