package com.grustentier.settings.user.controllers;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.grustentier.general.controllers.ControllerFacade;
import com.grustentier.general.dao.User;
import com.grustentier.general.dao.services.UserServiceImpl;

@Controller
@RequestMapping("/user-settings")
public class UserSettingPageNavigationController extends ControllerFacade {

	private final Log logger = LogFactory.getLog(UserSettingPageNavigationController.class);

	@Autowired
	UserServiceImpl userService;

	@GetMapping(value = "/")
	public String navToAdministrationHome(@RequestParam(name = "parent", required = false) String parent,
			@RequestParam(name = "tab", required = false) String tab, HttpServletRequest request, Model model) {
		updateNavigationHistory(request);

		model.addAttribute("parent", parent);
		model.addAttribute("tab", tab);
		return "/user-settings/index";
	}

	@PostMapping(value = "/general/change-username")
	public String changeUserNameRequest(@RequestParam(name = "username", required = true) String username,
			@RequestParam(name = "password", required = true) String password, HttpServletRequest request,
			HttpServletResponse response, Model model) throws IOException {

		String returnPage = "/user-settings/index";
		model.addAttribute("username", username);
		model.addAttribute("parent", "general");
		model.addAttribute("tab", "change-username");

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("usernameExists", false);
		result.put("wrongPassword", false);
		result.put("success", false);

		// check existing user to assigned username
		if (userService.userExists(username)) {
			result.put("usernameExists", true);
			model.addAttribute("result", result);
			return returnPage;
		}

		// check current HttpSession from HttpServletRequest
		HttpSession session = request.getSession();
		if (session == null) {
			logger.error("UserSettingPageNavigationController : changeUserNameRequest : Session is null");
			response.sendRedirect("/login");
		}

		// getting user over id from logged session user
		User user = userService.getUser();
		if (user == null) {
			logger.fatal("No user to id " + getUserId() + " has been found!",
					new UnsupportedOperationException("No user to id " + getUserId() + " has been found!"));
			return returnPage;
		}

		// match passwords via BCryptPasswordEncoder
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		if (encoder.matches(password, user.getPassword())) {
			user.setUsername(username);
			userService.saveUser(user);
			result.put("success", true);
			model.addAttribute("result", result);
			return returnPage;
		}

		result.put("wrongPassword", true);
		model.addAttribute("result", result);
		return returnPage;
	}

}
