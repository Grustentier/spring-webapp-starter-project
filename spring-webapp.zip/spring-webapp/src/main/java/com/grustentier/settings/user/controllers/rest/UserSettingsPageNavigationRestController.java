package com.grustentier.settings.user.controllers.rest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.grustentier.general.dao.ProfileImage;
import com.grustentier.general.dao.services.ProfileImageService;
import com.grustentier.general.file.services.FileStorageService;
import com.grustentier.general.session.SessionFacade;
import com.grustentier.general.utils.PathUtils;

import net.bytebuddy.utility.RandomString;

@RestController
public class UserSettingsPageNavigationRestController extends SessionFacade {

	private final Log logger = LogFactory.getLog(UserSettingsPageNavigationRestController.class);

	@Autowired
	FileStorageService fileStorageService;

	@Autowired
	private ProfileImageService profileImageService;

	@Autowired
	PathUtils pathUtils;

	@RequestMapping(value = "/user-settings/general/get-profile-image-path", method = RequestMethod.GET)
	public Map<String, Object> getProfileImagePath(HttpServletRequest request) throws IOException {

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("path", "");
		result.put("success", false);

		ProfileImage currentProfileImage = profileImageService.getProfileImage();
		if (currentProfileImage != null) {
			if (Files.exists(Paths.get(currentProfileImage.getExternalFilePath()))) {
				result.put("path", currentProfileImage.getInternalFilePath());
				result.put("success", true);
			} else {
				logger.error("Physical profile image for userId: " + getUserId() + " could not found in folder:  "
						+ currentProfileImage.getExternalFilePath());
			}
		}

		return result;
	}

	@RequestMapping(value = "/user-settings/general/upload-profile-image", method = RequestMethod.POST, consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE })
	public Map<String, Object> uploadProfileImage(@RequestPart MultipartFile file, HttpServletRequest request)
			throws IOException {

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("path", "");
		result.put("success", false);

		String fileExtension = FilenameUtils.getExtension(file.getOriginalFilename());
		String randomFileName = RandomString.make(64);

		Path externalPath = Paths.get(pathUtils.getExternalProfileImagePath().toString(),
				randomFileName + "." + fileExtension);
		Path internalPath = Paths.get(pathUtils.getInternalProfileImagePath().toString(),
				randomFileName + "." + fileExtension);

		ProfileImage currentProfileImage = profileImageService.getProfileImage();
		if (currentProfileImage == null) {
			currentProfileImage = new ProfileImage();
		}
		currentProfileImage.setFilename(file.getOriginalFilename());
		currentProfileImage.setUserId(getUserId());
		currentProfileImage.setExternalFilePath(externalPath.toString());
		currentProfileImage.setInternalFilePath(internalPath.toString());

		profileImageService.save(currentProfileImage);
		fileStorageService.cleanDirectory(pathUtils.getExternalProfileImagePath());
		fileStorageService.createDirectory(pathUtils.getExternalProfileImagePath());
		fileStorageService.save(file, externalPath);
		result.put("path", internalPath.toString());
		result.put("success", true);

		return result;
	}

	@RequestMapping(value = "/user-settings/general/delete-profile-image", method = RequestMethod.GET)
	public Map<String, Object> deleteProfileImage(HttpServletRequest request) throws IOException {

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", false);

		ProfileImage currentProfileImage = profileImageService.getProfileImage();

		if (currentProfileImage != null) {
			Path externalPath = Paths.get(currentProfileImage.getExternalFilePath());
			if (Files.exists(externalPath)) {
				fileStorageService.deleteFile(externalPath);
			}
			profileImageService.delete(currentProfileImage);
			result.put("success", true);
		}

		return result;
	}

}
